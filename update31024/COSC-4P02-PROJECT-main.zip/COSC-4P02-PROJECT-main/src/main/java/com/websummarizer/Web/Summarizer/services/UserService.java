package com.websummarizer.Web.Summarizer.services;


import com.websummarizer.Web.Summarizer.model.User;

public interface UserService {
    User createUser(User user);
}
