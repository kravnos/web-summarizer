package com.websummarizer.Web.Summarizer.common.exceptions;

import org.springframework.http.HttpStatus;

public class CCInternalServerError extends CCServerException{

    private static final HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

    public CCInternalServerError() {
        super(httpStatus);
    }

    public CCInternalServerError(String message) {
        super(message, httpStatus);
    }

    public CCInternalServerError(IError error) {
        super(error, httpStatus);
    }
}
