package com.websummarizer.Web.Summarizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebSummarizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebSummarizerApplication.class, args);
	}

}
