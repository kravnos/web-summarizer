package com.websummarizer.Web.Summarizer.common.exceptions;

import lombok.Getter;

@Getter
public enum ErrorCodes implements IError {

    // add list of error code and descriptions here
    ENTITY_NOT_FOUND(9000001, "Requested resource was not found"),
    SOME_OTHER_BUSINESS_EXCEPTON(9000002, "Something else went wrong");

    private Long errorCode;
    private String errorDescription;

    private ErrorCodes(long errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }
}
