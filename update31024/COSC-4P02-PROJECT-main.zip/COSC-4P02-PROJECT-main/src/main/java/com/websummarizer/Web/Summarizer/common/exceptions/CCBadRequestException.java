package com.websummarizer.Web.Summarizer.common.exceptions;

import org.springframework.http.HttpStatus;

public class CCBadRequestException extends CCServerException{

    private static final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

    public CCBadRequestException() {
        super(httpStatus);
    }

    public CCBadRequestException(String message) {
        super(message, httpStatus);
    }

    public CCBadRequestException(IError error) {
        super(error, httpStatus);
    }
}
