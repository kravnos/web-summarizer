package com.websummarizer.Web.Summarizer.common.exceptions;

public interface IError {
    public Long getErrorCode();

    public String getErrorDescription();
}
